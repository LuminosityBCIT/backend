import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import firebase from 'firebase';

// Initialize Firebase
  var config = {
    apiKey: "AIzaSyCfjkiraoyFSRLC_XJivAkNvFAg25Qi5CY",
    authDomain: "testing-c8227.firebaseapp.com",
    databaseURL: "https://testing-c8227.firebaseio.com",
    projectId: "testing-c8227",
    storageBucket: "testing-c8227.appspot.com",
};

firebase.initializeApp(config);
console.log(firebase);

//to connect firebase database to a variable
var database = firebase.database();

//making a reference to the database tree


var titleInput = document.getElementById("titleInput");
var urlInput = document.getElementById("urlInput");

class App extends Component {
        
      /* constructor(props){
          super(props);
          /* this.state = {
            title: "",
            url: ""
          } 
          
          
      } */
    
    
    submitBookmark(){
        var bookmark = {
            title: titleInput.value,
            url: urlInput.value
        }

        console.log(bookmark);
        var bookmarkRef = database.ref('users');
        bookmarkRef.push(bookmark);

        console.log(titleInput);
        console.log(urlInput);

        } 

    
    
      render() {

        return (
          <div className="App">
            <header className="App-header">
              <img src={logo} className="App-logo" alt="logo" />
              <h1 className="App-title">Welcome to React</h1>
            </header>
            <input type="text" id="titleInput" placeholder="title" />

            <input type="text" id="urlInput" placeholder="url" />

            <button onClick = {this.submitBookmark.bind(this)}>Bookmark</button>
          </div>
        );
      }
    }


export default App;
